import { createStore, combineReducers, Reducer, Store, compose } from 'redux'
import { LoginState, loginReducer } from '../login/reducers/main'
import { IIntlState, intlReducer } from '../common/reducers/I18nReducer'
import { ModalState } from '../common/modals/reducers/modalState'
import { modalReducer } from '../common/modals/reducers/modalReducer'
import { ServicesState, servicesReducer } from '../services/reducers/main'
import { AgentState, agentReducer } from '../agent/reducers/main'
import { CustomerState, customerReducer } from '../customer/reducers/main'
import { P360State, p360Reducer } from '../p360/reducers/main'
import { PaymentsState, paymentsReducer } from '../billing/components/PayBill/reducers/main'
import { DailyNoteLogState, DailyNoteLogReducer } from '../applicationHeader/reducers/mainDailyNoteLog'
import { NotesState, notesReducer } from '../applicationHeader/reducers/mainNote'
import { NotesHistoryState, noteshistoryReducer } from '../note/reducers/main'
import { SearchAccountState, searchAccountReducer } from '../searchAccount/reducers/main'
import { SelectAccountState, selectAccountReducer } from '../selectAccount/reducers/main'
import { CountryDDLStates, countryDDLReducer } from '../account/reducers/countryDDLmain'
import { StateDDLStates, stateDDLReducer } from '../account/reducers/stateDDLmain'
import { OneTimeChargeState, oneTimeChargeReducer } from '../account/reducers/mainOneTimeCharge'
import { NewChildAccountState, newChildAccountReducer } from '../newChildAccount/reducers/main'
import { BillingOverviewState, billingOverviewReducer } from '../billing/reducers/main'
import { AccountContactsState, AccountContactReducer } from '../account/components/contactDetails/reducers/main'
import { AdditionalInfoState, AdditionalInfoReducer } from '../account/reducers/mainAI'
import { DispMethodDDLState, dispMethodDDLReducer } from '../account/reducers/dispMethodDDLmain'
import { BillPreferencesState, BillPreferencesReducer } from '../account/reducers/mainBP'
import { PaymentProfileState, paymentProfileReducer } from '../account/components/paymentProfile/reducers/main'
import { CreatePaymentProfileState, createPaymentProfileReducer } from '../account/components/createPaymentProfile/reducers/main'
import { ManageTaxExemptionState, manageTaxExemptionReducer } from '../account/reducers/mainManageTaxExemption'
import { EditTaxExemptionState, editTaxExemptionReducer } from '../account/reducers/editTaxExemptionMain'
import { OnlineContactsState, onlineContactsReducer } from '../account/components/onlineContacts/reducers/main'
import { SupportState, supportPageReducer } from '../support/reducers/mainSupportPage'
import { RedirectionRulesState, redirectionRulesReducer } from '../account/reducers/mainRedirectionRules'
import { OrderingState, manageOrderingReducer } from '../ordering/reducers/OrderingCatalogFiltermain'
import { CreateRedirectionRuleState, createRedirectionRuleReducer } from '../account/reducers/createRedirectionRuleMain'

const persistStore = require('redux-persist').persistStore
const autoRehydrate = require('redux-persist').autoRehydrate

export interface AppState {
    intl: IIntlState
    login: LoginState
    services: ServicesState
    agentContext: AgentState
    customerContext: CustomerState
    modalContext: ModalState
    p360: P360State
    payments: PaymentsState
    notes: NotesState
    DailyNoteLog: DailyNoteLogState
    searchAccount: SearchAccountState
    noteshistory: NotesHistoryState
    selectAccount: SelectAccountState
    countryDDL: CountryDDLStates
    stateDDL: StateDDLStates
    oneTimeCharge: OneTimeChargeState
    newChildAccount: NewChildAccountState
    accountContacts: AccountContactsState
    AdditionalInfo: AdditionalInfoState
    dispMethodDDL: DispMethodDDLState
    BillPreferences: BillPreferencesState
    paymentProfile: PaymentProfileState
    createPaymentProfile: CreatePaymentProfileState
    manageTaxExemption: ManageTaxExemptionState
    editTaxExemption: EditTaxExemptionState
    onlineContacts: OnlineContactsState
    supportState: SupportState
    createRedirectionRules: CreateRedirectionRuleState
    redirectionRules: RedirectionRulesState
    orderingContext: OrderingState
}

const appReducer: Reducer<AppState> = combineReducers<AppState>({
    intl: intlReducer,
    login: loginReducer,
    services: servicesReducer,
    agentContext: agentReducer,
    customerContext: customerReducer,
    modalContext: modalReducer,
    p360: p360Reducer,
    notes: notesReducer,
    DailyNoteLog: DailyNoteLogReducer,
    searchAccount: searchAccountReducer,
    noteshistory: noteshistoryReducer,
    selectAccount: selectAccountReducer,
    countryDDL: countryDDLReducer,
    stateDDL: stateDDLReducer,
    oneTimeCharge: oneTimeChargeReducer,
    newChildAccount: newChildAccountReducer,
    accountContacts: AccountContactReducer,
    AdditionalInfo: AdditionalInfoReducer,
    payments: paymentsReducer,
    dispMethodDDL: dispMethodDDLReducer,
    BillPreferences: BillPreferencesReducer,
    paymentProfile: paymentProfileReducer,
    createPaymentProfile: createPaymentProfileReducer,
    manageTaxExemption: manageTaxExemptionReducer,
    editTaxExemption: editTaxExemptionReducer,
    onlineContacts: onlineContactsReducer,
    supportState: supportPageReducer,
    redirectionRules: redirectionRulesReducer,
    orderingContext: manageOrderingReducer,
    createRedirectionRules: createRedirectionRuleReducer
})

const rootReducer = (state, action) => {
    if (action.type === 'USER_LOGOUT') {
        let intl = {
            intl: {
                locale: state.intl.locale,
                messages: state.intl.messages
            }
        }
        state = undefined
        state = Object.assign({}, state, intl)
    }
    return appReducer(state, action)
}

export let appStore: Store<AppState> = compose(autoRehydrate())(createStore)(rootReducer, window['devToolsExtension'] && window['devToolsExtension']())

persistStore(appStore, { whitelist: ['intl', 'login'] })
