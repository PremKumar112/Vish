import React from 'react';

export default (
  <BoldText></BoldText>
)
