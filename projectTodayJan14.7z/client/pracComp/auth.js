import React, { Component } from 'react';
import TimeShow from './para';

export default class Auth extends Component{
  
  constructor(props){
  	super(props);
  	this.state = { element: null };
  	this.funS = this.funS.bind(this);
  }

  componentDidMount(){  	
  	setInterval(this.funS, 1000);
  }

  funS(){
  	this.setState({element: <TimeShow />});
  }

  render(){    
    return(
      <div>
      {this.state.element}
      </div>
    )
  }
}
