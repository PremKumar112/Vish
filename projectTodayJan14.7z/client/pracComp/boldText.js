import React, { Component } from 'react';

export default class Title extends Component{
  render(){
    return(
      <div>
      <br />
      <p>{this.props.children}</p>
      <br />
      </div>
    )
  }
}
