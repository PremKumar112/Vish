import React, { Component } from 'react';
import Time from 'react-time';

export default class TimeShow extends Component{

	render(){
		let date = new Date();
		let currentTime= date.toLocaleTimeString();

		return(
			<div className="container">
			<div className="row">
			<div className="col-lg-3"><p>I am Fine</p></div>
			<div className="col-lg-6"><h1>Today is {currentTime}</h1></div>
			<div className="col-lg-3"><p>Time is Going On</p></div>
			</div>
			</div>
			)
	}
}

