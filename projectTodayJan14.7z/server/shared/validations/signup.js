var Validator = require('validator');
var isEmpty = require('lodash/isEmpty');


module.exports=function validateInput(data){

  let errors= {};

  if(Validator.isEmpty(data.username)){
    errors.username = 'Please Enter the UserName';
  }
  if(Validator.isEmpty(data.email)){
    errors.email = 'Email is Required';
  }
  if(!Validator.isEmail(data.email)){
    errors.email = 'Email is inValid';
  }
  if(Validator.isEmpty(data.password)){
    errors.password = 'Password is Mandatory';
  }
  if(Validator.isEmpty(data.passwordConfirmation)){
    errors.passwordConfirmation = 'Please Confirm Your Password';
  }
  if(!Validator.equals(data.password, data.passwordConfirmation)){
    errors.passwordConfirmation= 'Passwords Must Match';
  }
  if(Validator.isEmpty(data.timezone)){
    errors.timezone = 'Must Enter a TimeZone';
  }
  return{
    errors,
    isValid: isEmpty(errors)
  }
}
