import React, { Component } from 'react';
import { Link, browserHistory } from 'react-router';

export default class NavigationBar extends Component{

  render(){

    return(
      <nav className="navbar navbar-default navcolor">
        <div className="container">
        <div className="navbar-header">
          <Link to="/" className="navbar-brand"><h4>Red Dice</h4></Link>
        </div>

        <div className="collapse navbar-collapse">
          <ul className="nav navbar-nav pull-right">
            <li><Link to="/signup">Sign Up </Link></li>
          </ul>
        </div>

        </div>
      </nav>
    )
  }

}
