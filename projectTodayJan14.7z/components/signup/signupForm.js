import React, { Component } from 'react';
import axios from 'axios';
import timezones from '../../client/datas/timezones';
import map from 'lodash/map';
import _ from 'lodash';
import classnames from 'classnames';
import validateInput from '../../server/shared/validations/signup';
import TextFieldGroup from '../common/TextFieldGroup';
import { Link } from 'react-router';
import { browserHistory } from 'react-router';
require('../../client/assets/app.scss');


class SignupForm extends Component{

    constructor(props){
      super(props);
      this.state={
        username: '',
        email: '',
        password: '',
        passwordConfirmation: '',
        timezone: '',
        errors: {},
        isLoading: false
      }
      this.onChange = this.onChange.bind(this);
      this.submitForm = this.submitForm.bind(this);
      this.clearForm = this.clearForm.bind(this);
      this.isValid = this.isValid.bind(this);
    }

    onChange(e){
      this.setState({ [e.target.name]: e.target.value});
    }


    // isValid function to validate the form inputs on the client side
    isValid(){
      const { errors, isValid }= validateInput(this.state);
      if(!isValid){
        this.setState({ errors });
      }
      return isValid;

    }

    submitForm(e){
      e.preventDefault();
      const root = this.context.router;
      if(this.isValid()){
        this.setState({ errors: {}, isLoading: true });
        var request = this.props.userSignupRequest(this.state);
        request.then(function(response){
            root.push('/');
        })
        .catch((error)=>{
  	      this.setState({ errors: error.response.data, isLoading: false });
        })
      }

    }
    clearForm(e){
        e.preventDefault();
        //!(this.submitForm(e));
        this.setState({ username: '',
        email: '',
        password: '',
        passwordConfirmation: '',
        timezone: '', errors: {}, isLoading: false });
    }

render(){
      const { errors, username, email, password, passwordConfirmation, timezone } = this.state;
      const validPassword = password===passwordConfirmation ? true : false;
      let lex={};
      if(errors!==undefined){
        lex=errors;
      }
      const options = map(timezones, (val, key)=>
        <option key={val} value={val}>{key}</option>
      );
return(
  <form onSubmit={this.submitForm}>
    <h1>Join Our Community</h1>

          <TextFieldGroup className="warning"
          error={errors.username}
          placeholder="Enter Your UserName Here"
          label="UserName"
          onChange={this.onChange}
          value={this.state.username}
          field="username"
          />

          <TextFieldGroup
          error={errors.email}
          placeholder="Enter Your Email Here"
          label="Email"
          onChange={this.onChange}
          value={this.state.email}
          field="email"
          />

          <TextFieldGroup
          error={errors.password}
          placeholder="Please Enter Your Password"
          label="Password"
          onChange={this.onChange}
          value={this.state.password}
          field="password"
          type="password"
          />

          <TextFieldGroup
          error={errors.passwordConfirmation}
          placeholder="Confirm Password"
          label="Password Confirmation"
          onChange={this.onChange}
          value={this.state.passwordConfirmation}
          field="passwordConfirmation"
          type="password"
          />

          <div className={classnames("form-group", { 'has-error': errors.timezone})}>
            <label className="control-label">TimeZone</label>
            <select
            className="form-control"
            name="timezone"
            onChange={this.onChange}
            value={this.state.timezone}
            >
            <option value="" disabled>Choose Your Timezone</option>
            {options}
            </select>
            {lex.timezone && <span className="help-block">{lex.timezone}</span>}
          </div>
          {username && email && password && passwordConfirmation && validPassword && options &&
            timezone && <div className="form-group">
            <button disabled={this.state.isLoading} className="btn btn-primary btn-lg">
              Sign Up <span className="caret"></span></button>
            <span className="warn">
            <button onClick={this.clearForm} className="btn btn-info btn-lg">
            Clear Form</button>
            </span>
            <span className="warn">
            <button onClick={(e)=>{e.preventDefault(); this.context.router.push('/')}} 
            className="btn btn-warn btn-lg">
            GoTo Home Page</button>
            </span>
            </div>}
        </form>
      )
    }
}

SignupForm.propTypes = {
  userSignupRequest: React.PropTypes.func.isRequired
}

SignupForm.contextTypes = {
  router: React.PropTypes.object.isRequired
}

export default SignupForm;
