export default function(state=null, action){
	console.log('Action Recieved', action);
	return state;
}
